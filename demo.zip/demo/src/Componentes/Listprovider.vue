<template>
    <div class="list row">
        <div class="col-md-6">
            <h4>Proveedores Lista</h4>
            <ul>
                <li v-for="(proveedor, index) in proveedores" :key="index">
                    <router-link :to="{
                            name: 'proveedor-details',
                            params: { proveedor: proveedor, id: proveedor.id }}">
                            {{proveedor.name}}
                    </router-link>
                </li>
            </ul>
        </div>
        <div class="col-md-6">
            <router-view @refreshData="refreshList"></router-view>
        </div>
    </div>
</template>
 
<script>
import http from "../http-common";
 
export default {
  name: "proveedor-list",
  data() {
    return {
     proveedor: []
    };
  },
  methods: {
    /* eslint-disable no-console */
    retrieveProveedores() {
      http
        .get("/providerd")
        .then(response => {
          this.proveedores = response.data; // JSON are parsed automatically.
          console.log(response.data);
        })
        .catch(e => {
          console.log(e);
        });
    },
    refreshList() {
      this.retrieveProveedores();
    }
    /* eslint-enable no-console */
  },
  mounted() {
    this.retrieveProveedores();
  }
};
</script>
 
<style>
.list {
  text-align: left;
  max-width: 450px;
  margin: auto;
}
</style>