<template>
  <div v-if="this.proveedor">
    <h4>Proveedores</h4>
    <div>
      <label>ID: </label> {{this.proveedor.id}}
    </div>
    <div>
      <label>Nombre: </label> {{this.proveedor.nombre}}
    </div>
    <div>
      <label>Descripcion: </label> {{this.proveedor.descripcion}}
    </div>
    <div>
      <label>Direccion: </label> {{this.proveedor.direccion}}
    </div>
    <div>
      <label>Telefono: </label> {{this.proveedor.telefono}}
    </div>
    <div>
      <label>Correo: </label> {{this.proveedor.correo}}
    </div>
    <div>
      <label>Estado: </label> {{this.proveedor.estado}}
    </div>
    <div>
      <label>Active: </label> {{this.provider.active}}
    </div>
  
    <span v-if="this.proveedor.active"
      v-on:click="updateActive(false)"
      class="button is-small btn-primary">Inactive</span>
    <span v-else
      v-on:click="updateActive(true)"
      class="button is-small btn-primary">Active</span>
  
    <span class="button is-small btn-danger" v-on:click="deleteProveedor()">Delete</span>
  </div>
  <div v-else>
    <br/>
    <p>Please click on a Proveedor...</p>
  </div>
</template>
 
<script>
import http from "../http-common";
 
export default {
  name: "proveedor",
  props: ["proveedor"],
  methods: {
    /* eslint-disable no-console */
    updateActive(status) {
      var data = {
        ID: this.proveedor.ID,
        nombre: this.proveedor.nombre,
        descripcion: this.proveedor.descripcion,
        direccion: this.proveedor.direccion,
        telefono: this.proveedor.telefono,
        correo: this.proveedor.correo,
        estado: this.proveedor.estado
      };
 
      http
        .put("/proveedor/" + this.proveedor.id, data)
        .then(response => {
          this.proveedor.active = response.data.active;
          console.log(response.data);
        })
        .catch(e => {
          console.log(e);
        });
    },
    deleteProveedor() {
      http
        .delete("/proveedor/" + this.proveedor.id)
        .then(response => {
          console.log(response.data);
          this.$emit("refreshData");
          this.$router.push('/');
        })
        .catch(e => {
          console.log(e);
        });
    }
    /* eslint-enable no-console */
  }
};
</script>