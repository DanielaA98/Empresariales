<template>
  <div class="submitform">
    <div v-if="!submitted">

        <div class="form-group">
          <label for="ID">ID</label>
          <input type="text" class="form-control" id="ID" required v-model="proveedor.ID" name="ID">
        </div>

        <div class="form-group">
          <label for="nombre">Nombre</label>
          <input type="text" class="form-control" id="nombre" required v-model="proveedor.nombre" name="nombre">
        </div>

        <div class="form-group">
          <label for="descripcion">Descripcion</label>
          <input type="text" class="form-control" id="descripcion" required v-model="proveedor.descripcion" name="descripcion">
        </div>
        
        <div class="form-group">
          <label for="direccion">Direccion</label>
          <input type="text" class="form-control" id="direccion" required v-model="proveedor.direccion" name="direccion">
        </div>

        <div class="form-group">
          <label for="telefono">Telfono</label>
          <input type="text" class="form-control" id="telefono" required v-model="proveedor.telefono" name="telefono">
        </div>
        
        <div class="form-group">
          <label for="correo">Correo</label>
          <input type="text" class="form-control" id="correo" required v-model="proveedor.correo" name="correo">
        </div>

        <div class="form-group">
          <label for="estado">Estado</label>
          <input type="text" class="form-control" id="estado" required v-model="proveedor.estado" name="estado">
        </div>
    
        <button v-on:click="saveProveedor" class="btn btn-success">Submit</button>
    </div>
    
    <div v-else>
      <h4>You submitted successfully!</h4>
      <button class="btn btn-success" v-on:click="newProveedor">Add</button>
    </div>
  </div>
</template>
 
<script>
import http from "../http-common";
 
export default {
  name: "add-proveedor",
  data() {
    return {
      provider: {
        id: 0,
        name: "",
        age: 0,
        active: false
      },
      submitted: false
    };
  },
  methods: {
    /* eslint-disable no-console */
    saveProveedor() {
      var data = {
        ID: this.proveedor.ID,
        nombre: this.proveedor.nombre,
        descripcion: this.proveedor.descripcion,
        direccion: this.proveedor.direccion,
        telefono: this.proveedor.telefono,
        correo: this.proveedor.correo,
        estado: this.proveedor.estado
       
      };
 
      http
        .post("/provider", data)
        .then(response => {
          this.provider.id = response.data.id;
          console.log(response.data);
        })
        .catch(e => {
          console.log(e);
        });
 
      this.submitted = true;
    },
    newProvider() {
      this.submitted = false;
      this.provider = {};
    }
    /* eslint-enable no-console */
  }
};
</script>
 
<style>
.submitform {
  max-width: 300px;
  margin: auto;
}
</style>