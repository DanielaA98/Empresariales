import Vue from "vue";
import Router from "vue-router";
import Listprovider from "./components/Listprovider.vue";
import AddProvider from "./components/AddProvider.vue";
import SearchProvider from "./components/SearchProvider.vue";
 
Vue.use(Router);
 
export default new Router({
  // get rid of the hash (#) in Url
  // the hash (#) helps the page not to be reloaded when the URL changes
  mode: "history",
  routes: [
    {
      path: "/",
      name: "proveedores",
      alias: "/proveedor", // go '/', the URL remains '/', but it wcill be matched if visiting '/customer'
      component: Listprovider
    },
    {
      path: "/add",
      name: "add",
      component: AddProvider
    },
    {
      path: "/search",
      name: "search",
      component: SearchProvider
    }
  ]
});