<template>
  <div class="searchform">
    <h4>Encontrar por Nombre</h4>
    <div class="form-group">
      <input type="text" class="form-control" id="nombre" required v-model="nombre" name="nombre">
    </div>
 
    <div class="btn-group">
      <button v-on:click="searchProveedor" class="btn btn-success">Search</button>
    </div>
 
    <ul class="search-result">
      <li v-for="(proveedor, index) in proveedores" :key="index">
        <h6>{{proveedor.ID}}{{proveedor.nombre}}{{provider.descripcion}}{{provider.direccion}}{{provider.teleono}}{{provider.correo}}{{provider.estado}}</h6>
      </li>
    </ul>
  </div>
</template>
 
<script>
import http from "../http-common";
 
export default {
  name: "search-proveedor",
  data() {
    return {
      id: 0,
      proveedores: []
    };
  },
  methods: {
    /* eslint-disable no-console */
    searchProveedores() {
      http
        .get("/proveedores/nombre/" + this.nombre)
        .then(response => {
          this.proveedores = response.data; // JSON are parsed automatically.
          console.log(response.data);
        })
        .catch(e => {
          console.log(e);
        });
    }
    /* eslint-enable no-console */
  }
};
</script>
 
<style>
.searchform {
  max-width: 300px;
  margin: auto;
}
.search-result {
  margin-top: 20px;
  text-align: left;
}
</style>