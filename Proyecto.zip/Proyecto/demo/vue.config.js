module.exports = {
    devServer: {
      port: 4200
    }
  }